Programa de la actividad 2_B Unidad 1.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

Este programa utiliza SAX para leer un documento XML que contiene informacion sobre libros.
Convierte esta informacion en objetos Java, la pinta por consola y la escribe en archivos .txt según el año.

Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Ejecutar App.java en app\src\main\java\u1ex02b\
