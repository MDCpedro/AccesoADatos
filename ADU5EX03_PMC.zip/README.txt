Programa de la actividad 3 Unidad 5.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

· Funcionalidad
Programa que se conecta a una base de datos MongoDB, el usuario puede
especificar que coleccion buscar en la BD. Al conectarse, este programa
lee todos los JSONS de la BD y los convierte a XML, los imprime por consola
y guarda en un archivo.

Uso del programa:
1- Usar VisualStudioCode / Intelij , para abrir la carpeta del proyecto.
2- Ejecutar el archivo "Main.java" en la ruta adu5ex03\src\main\java\com\example\
3- Al ejecutar el programa este se conectará a la base de datos especificada en el código, 
y nos pedirá en la consola que escribamos la coleccion de esta. En este caso es "correccio".
4- Si es correcta, el programa procederá a mostrar todos los XML por consola y guardarlos como archivos en la carpeta del programa.
5- En caso de equivocarnos al escribir la coleccion, ejecutar el programa y volvemos a intentarlo.
