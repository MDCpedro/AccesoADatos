Programa de la actividad 2_A Unidad 1.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

Este programa lee un XML (de libros) y muestra la informacion en la terminal de cada uno de estos. 
Además en la carpeta resources crea un .txt de cada autor y pone la info de su libro.

Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Ejecutar App.java en app\src\main\java\u1ex01\
