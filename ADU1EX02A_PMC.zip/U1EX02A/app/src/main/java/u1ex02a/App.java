package u1ex02a;

import u1ex02a.LectorXML;

public class App {
    public static void main(String[] args) {
       LectorXML lectorXML = new LectorXML();
       lectorXML.leerXML();
    }
}
