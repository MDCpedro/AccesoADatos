Programa de la actividad 1 Unidad 2.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

· Funcionalidad
Aplicación que se conecta a una base de datos MySQL, 
El programa permitirá elegir entre dos funcionalidades: introducir datos de empleados o leer e 
imprimir los datos de la base de datos.

Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Ejecutar Main.java en u2ex01\src\main\java\com\example\
