Programa de la actividad 1 Unidad 1.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code

Este programa copia la informacion de uno de los archivos
en la carpeta resources y la pega en un nuevo archivo destino.

Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Dirigirse a app\src\main\java\u1ex01\
3- Ejecutar App43235705y.java