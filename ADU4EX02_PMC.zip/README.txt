Programa de la actividad 2 Unidad 4.
Lenguaje: Java 17.0.8
IDE: Intellij Ultimate
SO: Windows 10

· Funcionalidad
Aplicación que se conecta a una base de datos MySQL usando Hibernate en Maven.
El programa permitirá elegir entre dos tipos de entidad: Autores o Libros,
y permitir crear eliminar modificar y leer una lista de estos.

Uso del programa:
1- Usar visual studio code o Intelij para abrir la carpeta del proyecto.
2- Ejecutar Main.java en u4ex02/src/main/java/org/example/

Base de datos:

El programa no crea la base de datos si no existe, para crearla:
1- Abrir mysql workbench.
2- Crear la base de datos "biblioteca"
3- hacer el siguiente insert de tablas: 
CREATE TABLE Autor (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    dataNaixement DATE
);

CREATE TABLE Llibre (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titol VARCHAR(255) NOT NULL,
    anyPublicacio INT,
    autor_id INT,
    FOREIGN KEY (autor_id) REFERENCES Autor(id) ON DELETE SET NULL
);

4- Usar usuario "root", Contraseña "cide2050"
