Programa de la actividad 2 Unidad 5.
Lenguaje: Java 17.0.8
IDE: Intelij Ultimate
SO: Windows 10

· Funcionalidad
Programa con metodos que transforma XML a JSON, JSON a BSON y viceversa.
En este caso lee un XML de la carpeta /resources, lo transforma a JSON y lo guarda,
y procede a convertirlo a XML de nuevo.

Uso del programa:
1- Usar VisualStudioCode / Intelij , para abrir la carpeta del proyecto.
2- Ejecutar Main.java en src/main/java/org/example/
