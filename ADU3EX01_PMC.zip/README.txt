Programa de la actividad 1 Unidad 3.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

· Funcionalidad
Esta aplicacion utiliza Object Data Base para gestionar la base de datos que se encuentran en los archivos del programa.
Nos permite gestionar Personas y Empresas un menu interactivo para seleccionar funciones como; Crear, Eliminar, Modificar o Mostrar
cada entidad de esta base de datos.

· Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Ejecutar Main.java en u3ex01\src\main\java\com\example\
