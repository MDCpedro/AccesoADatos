Programa de la actividad 2.C Unidad 1.
Lenguaje: Java 17.0.8
IDE: Visual Studio Code
SO: Windows 10

Este programa utiliza JAXB para leer un documento XML que contiene información sobre libros y convertirlos en objetos Java.
Imprime por consola el resultado, y luego escribe en un archivo cada libro por orden cronologico.


Uso del programa:
1- Usar visual studio code para abrir la carpeta del proyecto.
2- Ejecutar Main.java en u1ex02c\src\main\java\com\example\
